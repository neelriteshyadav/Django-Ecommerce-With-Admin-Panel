from django.contrib import admin
from .models import Products, Coupons


class ProductsAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'stock')


admin.site.register(Products, ProductsAdmin)


class CouponsAdmin(admin.ModelAdmin):
    list_display = ('coupon_code', 'coupon_desc', 'coupon_disc')


admin.site.register(Coupons, CouponsAdmin)