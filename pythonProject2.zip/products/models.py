from django.db import models


class Products(models.Model):
    name = models.CharField(max_length=255)
    price = models.FloatField()
    stock = models.IntegerField()
    image_url = models.CharField(max_length=2083)


class Coupons(models.Model):
    coupon_code = models.CharField(max_length=20)
    coupon_desc = models.CharField(max_length=2083)
    coupon_disc = models.FloatField()
